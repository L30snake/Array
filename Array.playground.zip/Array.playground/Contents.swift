import UIKit

//My Funko POP Collection
var FunkoCollection: [String] = ["Marvel End Game Collection","10 Funkos"]

FunkoCollection += ["DeadPool collection", "5 Funkos", "Marvel InfinityWar", "10 Funkos", "Video games collection", "10 Funkos", "Stan Lee", "5 Funkos", "Anime collection", "10 Funkos"]


print("The collection is conplete \(FunkoCollection.count) items.")
if FunkoCollection.isEmpty {
    print("The collection is not conplete.")
} else {
    print("The collection is conplete.")
}

var Collectiontotal = 50

let DeadpoolFunkos = 5
let EndGameFunkos = 10
let InfinityWarFunkos = 10
let StanLeeFunkos = 5
let Videogamesfunkos = 10
let Animefunkos = 10

Collectiontotal
Collectiontotal -= DeadpoolFunkos
Collectiontotal -= EndGameFunkos
Collectiontotal -= InfinityWarFunkos
Collectiontotal -= StanLeeFunkos
Collectiontotal -= Videogamesfunkos
Collectiontotal -= Animefunkos

